package multiplexerproject;

/**
 * This represents the input. 
 * @version 1.0
 * @author Marc
 * @since 25.12.2017
 */
public class Input {

    private char value;
    private int inputId;
    
    /**
     * This is a constructor. Creates an Input with value and inputID.
     * @param value The value of the Input.
     * @param inputId The inputID of the Input.
     */
    public Input(char value, int inputId){
        this.value=value;
        this.inputId=inputId;
    }
    
    
    /**
     * Sets the value of the input
     * @param value The int containing the value.
     */
    public void setValue(int value) {
        this.value = (char) value;
    }

    /**
     * Sets the InpudID of the input
     * @param inputId This is the Inputid to be set.
     */
    public void setInputId(int inputId) {
        this.inputId = inputId;
    }

    /**
     * Gets the value of an Input.
     * @return the value of the Input.
     */
    public char getValue() {
        return value;
    }

    /**
     * This returns the Inputid of an Input. 
     * @return This is the inputId.
     */
    public int getInputId() {
        return inputId;
    }


}
