/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multiplexerproject;

/**
 *
 * @author Marc
 */
public class Input {

    private char value;
    private int inputId;
    
    public Input(char value, int inputId){
        this.value=value;
        this.inputId=inputId;
    }
    
    
    public void setValue(int value) {
        this.value = (char) value;
    }

    public void setInputId(int inputId) {
        this.inputId = inputId;
    }

    public char getValue() {
        return value;
    }

    public int getInputId() {
        return inputId;
    }


}
