/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplexerproject;

/**
 *
 * @author Marc
 */
public class STDMMultiplexer extends Multiplexer {
    
    public STDMMultiplexer(int inputNumber){
      super(inputNumber);  
    }

    private String type = "STDM";

    public String getType() {
        return type;
    }

    @Override
    public void mux(PCM pcm) {
        for (int i = 0; i < pcm.getChannels().length; i++) {
            System.out.print("|" + toBinary(pcm.getChannels()[i].getValue()) + "Channel " + pcm.getChannels()[i].getChannelNr());
        }
        System.out.print("|\n");
    }

}
