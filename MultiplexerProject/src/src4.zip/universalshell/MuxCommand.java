/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universalshell;

import multiplexerproject.Multiplexer;
import multiplexerproject.PCM;
import universalshell.command.Command;
import universalshell.output.Output;

/**
 *
 * @author Marc
 */
class MuxCommand extends Command {
    private Multiplexer multiplexer;
    private PCM pcm;
    private Output output;

    public MuxCommand(Multiplexer multiplexer, PCM pcm, Output output) {
        this.multiplexer = multiplexer;
        this. pcm = pcm;
        this.output = output;
    }

    @Override
    public void execute() {
    if (multiplexer != null) {   
        multiplexer.mux(pcm);  
    }
    else {
     output.writeLine("Please create multiplexer");
    }
    }
    
}
