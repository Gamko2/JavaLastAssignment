/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multiplexerproject;

/**
 *
 * @author Marc
 */
public abstract  class Multiplexer {
    private int inputNr;
    private Input[] inputs;
    
   


   public abstract void mux(PCM pcm);
    
     
    public Multiplexer (int inputNr){
        this.inputNr = inputNr;
        inputs = new Input[inputNr];
        for (int i= 0; i<inputNr ; i++){
            inputs[i]= new Input((char)0,i+1);   
        }
       
    }
    
    public int getInputNr(){
        return inputNr;
    }
    
    public Input getInput(int inputId){
        return inputs[inputId-1];
    }
    
            protected String toBinary(char value) {
        String tmp = "";
        for (int x = 7; x >= 0; x--) {
            tmp += ((1 << x) & value) != 0 ? "1" : "0";
        }
        return tmp;
    }

}
