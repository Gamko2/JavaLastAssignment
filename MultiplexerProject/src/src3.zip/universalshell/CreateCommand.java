/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universalshell;

import multiplexerproject.STDMMultiplexer;
import universalshell.command.Command;
import universalshell.output.Output;

/**
 *
 * @author Marc
 */
class CreateCommand extends Command {

    private String[] args;
    private Output output;
    private MultiplexerCommandFactory mpcf;

    public CreateCommand(String[] args, Output output, MultiplexerCommandFactory mpcf) {
        this.args = args;
        this.output = output;
        this.mpcf = mpcf;
    }

    @Override
    public void execute() {
        String[] multiplexerdetails = args[1].split(":");
        if (multiplexerdetails.length == 2) {
            if (multiplexerdetails[0].equals("stdm")) {
                try {
                    int number = Integer.valueOf(multiplexerdetails[1]);
                    mpcf.setMultiplexer(new STDMMultiplexer(number));
                    output.writeLine("STDM multiplexer created");

                } catch (NumberFormatException nfe) {
                    output.writeLine("Wrong Input");
                }
            } else if (multiplexerdetails[0].equals("atd")) {
                output.writeLine("This type is not implemented");
            } else if (multiplexerdetails[0].equals("cdm")) {
                output.writeLine("This type is not implemented");
            }
        } else {
            output.writeLine("Wrong Input");
        }
    }

}
