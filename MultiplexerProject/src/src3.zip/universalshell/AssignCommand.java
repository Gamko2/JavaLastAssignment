/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universalshell;

import universalshell.command.Command;
import universalshell.output.Output;

/**
 *
 * @author Marc
 */
class AssignCommand extends Command {

    private String[] args;
    private MultiplexerCommandFactory mpcf;
    private Output output;

    public AssignCommand(String[] args, MultiplexerCommandFactory mpcf, Output output) {
        this.args = args;
        this.mpcf = mpcf;
        this.output = output;
    }

    @Override
    public void execute() {
      if (mpcf.getMultiplexer() != null){
                 String[] values = args[1].split(":");
        if (values.length == 2) {
            try {
                int channelid = Integer.valueOf(values[0]);
                int inputid = Integer.valueOf(values[1]);
                mpcf.getPCM().assignChannel(channelid, mpcf.getMultiplexer().getInput(inputid));
                output.writeLine("Assignment created");
            } catch (NumberFormatException nfe) {
                output.writeLine("Wrong Input");
            }

        }
      } else {
          output.writeLine ("Please create multiplexer");
      }
    }
}
