/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universalshell;

import universalshell.command.Command;

/**
 *
 * @author Marc
 */
class ExitCommand extends Command {
    private final UniversalShell shell;

    public ExitCommand(UniversalShell shell) {
        this.shell = shell;
    }

    @Override
    public void execute() {
     shell.close();   
    }
    
}
