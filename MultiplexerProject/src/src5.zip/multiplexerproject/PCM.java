/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplexerproject;

/**
 *
 * @author Marc
 */
public class PCM {

    private boolean even = true;
    private Channel[] channels = new Channel[32];

    public PCM() {
        for (int i = 0; i < channels.length; i++) {
            channels[i] = new Channel((char) 0, i);
        }

        if (even) {
            channels[0].setValue((char) 27);
        } else {
            channels[0].setValue((char) 64);
        }
        channels[16].setValue((char) 95);

        even = (!even);
    }
    
    public void assignChannel (int channelId, Input input){
        if (channelId != 16){
        channels[channelId].setInput(input);
        }
    }
    
    public Channel[] getChannels(){
        return channels;
    }
}
