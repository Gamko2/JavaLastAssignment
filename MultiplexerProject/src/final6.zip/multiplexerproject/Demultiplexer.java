/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplexerproject;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Marc
 */
public class Demultiplexer {

    private int OutputNr;
    private List<Output> outputs = new ArrayList<Output>();

    private static Demultiplexer demultiplexer = new Demultiplexer();

    private Demultiplexer() {
        for (int i = 0; i < 31; i++) {
            outputs.add(i, new Output((char) 0, i));
        }

    }

    public static Demultiplexer getDemultiplexer() {
        return demultiplexer;
    }

    public Output getOutput(int id) {
        return outputs.get(id);
    }

    public void demux(PCM pcm) {
        for (Channel channel : pcm.getChannels()) {
            if (channel.getObserver() != null && channel.getObserver() instanceof Output) {
                Output output = (Output) channel.getObserver();
                System.out.print((int)output.getValue() + " ");
            }
        }
        System.out.println("");

    }

}
