/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universalshell;

import universalshell.command.Command;
import universalshell.output.Output;

/**
 *
 * @author Marc
 */
class InputCommand extends Command {

    private String[] args;
    private MultiplexerCommandFactory mpcf;
    private Output output;

    public InputCommand(String[] args, MultiplexerCommandFactory mpcf, Output output) {
        this.args = args;
        this.mpcf = mpcf;
        this.output = output;
    }

    @Override
    public void execute() {

        String[] values = args[1].split(":");
        if (values.length == 2) {
            try {
                int input = Integer.valueOf(values[0]);
                char convertedinput = (char) input;
                int inputid = Integer.valueOf(values[1]);
                if (mpcf.getMultiplexer() != null) {
                    mpcf.getMultiplexer().getInput(inputid).setValue(convertedinput);
                    output.writeLine("Value assigned");
                } else {
                    output.writeLine("Please create multiplexer");
                }
            } catch (NumberFormatException nfe) {
                output.writeLine("Wrong Input");
            }

        }

    }
}
