/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplexerproject;

/**
 *
 * @author Marc
 */
public class PCM {

    private boolean even = true;
    private Channel[] channels = new Channel[32];

    public PCM() {
        for (int i = 0; i < channels.length; i++) {
            channels[i] = new Channel((char) 0, i);
        }
        setEven(true);
        channels[16].setValue((char) 95);
    }

    public void assignChannel(int channelId, Input input) {
        if (channelId < 16) {
            for (int i = 0; i < channels.length; i++) {
                if (channels[i].getInput() != null && input.getInputId() == channels[i].getInput().getInputId()) {
                    channels[i].setInput(null);
                    break;
                }
            }
            channels[channelId].setInput(input);
        }
        if (channelId >= 16){
            for (int i = 16 ; i < channels.length ; i++){
                if (channels[i+1].getInput() != null && input.getInputId() == channels[i+1].getInput().getInputId()){
                channels[i+1].setInput(null);
                break;
            }
            }
            channels[channelId + 1].setInput(input);
        }
    }

    public Channel[] getChannels() {
        return channels;
    }

    public boolean isEven() {
        return even;
    }

    public void setEven(boolean even) {
        this.even = even;
        if (even) {
            channels[0].setValue((char) 27);
        } else {
            channels[0].setValue((char) 64);
        }
    }
}
