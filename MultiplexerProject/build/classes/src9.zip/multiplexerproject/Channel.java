/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplexerproject;

/**
 *
 * @author Marc
 */
public class Channel {

    private char value;
    private Input input;
    private int channelNr;

    public Channel(char value, int channelNr) {
        this.value = value;
        this.channelNr = channelNr;
    }

    public void setValue(char value) {
        if (input != null) {
            input.setValue(value);
        } else {
            this.value = value;
        }
    }

    public void setChannelNr(int channelNr) {
        this.channelNr = channelNr;
    }

    public char getValue() {
        if (input != null) {
            return input.getValue();
        } else {
            return value;
        }
    }

    public int getChannelNr() {
        return channelNr;
    }
    
    public void setInput(Input input){
        this.input=input;
    }
    
    public Input getInput(){
        return input;
    }
    

}
